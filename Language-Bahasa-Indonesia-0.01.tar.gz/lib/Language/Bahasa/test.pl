#!perl


use Indonesia;




cetak "cetak";





__END__
cetak "Halo ! Apa kabar dunia ??\n";

rutin gokil{

bunuh "$0 dengan PROCESS ID: $$ telah dibunuh\n";
}


=head1 DESCRIPTION
		
		Test program ini dibuat oleh DaNiels.
		Filter::Util::Call dan Language::Bahasa::Indonesia akan di-porting ke C untuk
		pengembangan lebih lanjut.

=head1 AUTHOR
		Daniels <dns@cpan.org>

=head1 SEE ALSO
		Filter::Util::Call